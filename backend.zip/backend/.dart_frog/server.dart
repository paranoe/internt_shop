// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, implicit_dynamic_list_literal

import 'dart:io';

import 'package:dart_frog/dart_frog.dart';


import '../routes/index.dart' as index;
import '../routes/health.dart' as health;
import '../routes/subcategories/[id]/parameters.dart' as subcategories_$id_parameters;
import '../routes/subcategories/[id]/filters.dart' as subcategories_$id_filters;
import '../routes/seller/profile.dart' as seller_profile;
import '../routes/seller/products/index.dart' as seller_products_index;
import '../routes/seller/products/[id]/upload_image.dart' as seller_products_$id_upload_image;
import '../routes/seller/products/[id]/set_main_image.dart' as seller_products_$id_set_main_image;
import '../routes/seller/products/[id]/parameters.dart' as seller_products_$id_parameters;
import '../routes/seller/products/[id]/index.dart' as seller_products_$id_index;
import '../routes/seller/products/[id]/images.dart' as seller_products_$id_images;
import '../routes/seller/orders/index.dart' as seller_orders_index;
import '../routes/seller/orders/[id].dart' as seller_orders_$id;
import '../routes/reviews/index.dart' as reviews_index;
import '../routes/reviews/can-review.dart' as reviews_can_review;
import '../routes/products/search_filters.dart' as products_search_filters;
import '../routes/products/index.dart' as products_index;
import '../routes/products/[id]/reviews.dart' as products_$id_reviews;
import '../routes/products/[id]/parameters.dart' as products_$id_parameters;
import '../routes/products/[id]/index.dart' as products_$id_index;
import '../routes/products/[id]/images.dart' as products_$id_images;
import '../routes/pickup-points/index.dart' as pickup_points_index;
import '../routes/payments/index.dart' as payments_index;
import '../routes/payment-methods/index.dart' as payment_methods_index;
import '../routes/orders/index.dart' as orders_index;
import '../routes/orders/[id].dart' as orders_$id;
import '../routes/measurement-units/index.dart' as measurement_units_index;
import '../routes/measurement-units/[id].dart' as measurement_units_$id;
import '../routes/me/index.dart' as me_index;
import '../routes/me/pickup-points/index.dart' as me_pickup_points_index;
import '../routes/me/pickup-points/[id].dart' as me_pickup_points_$id;
import '../routes/me/cards/index.dart' as me_cards_index;
import '../routes/me/cards/[id].dart' as me_cards_$id;
import '../routes/list-types/index.dart' as list_types_index;
import '../routes/favorites/index.dart' as favorites_index;
import '../routes/favorites/[id].dart' as favorites_$id;
import '../routes/cities/index.dart' as cities_index;
import '../routes/checkout/preview.dart' as checkout_preview;
import '../routes/checkout/create.dart' as checkout_create;
import '../routes/categories/index.dart' as categories_index;
import '../routes/categories/[id]/subcategory_parameters.dart' as categories_$id_subcategory_parameters;
import '../routes/categories/[id]/subcategories.dart' as categories_$id_subcategories;
import '../routes/cart/index.dart' as cart_index;
import '../routes/cart/items/index.dart' as cart_items_index;
import '../routes/cart/items/[id].dart' as cart_items_$id;
import '../routes/auth/verify-email.dart' as auth_verify_email;
import '../routes/auth/reset-password.dart' as auth_reset_password;
import '../routes/auth/resend-verification-code.dart' as auth_resend_verification_code;
import '../routes/auth/register.dart' as auth_register;
import '../routes/auth/refresh.dart' as auth_refresh;
import '../routes/auth/logout.dart' as auth_logout;
import '../routes/auth/login.dart' as auth_login;
import '../routes/auth/forgot-password.dart' as auth_forgot_password;
import '../routes/admin/users/index.dart' as admin_users_index;
import '../routes/admin/users/[id].dart' as admin_users_$id;
import '../routes/admin/subcategory-parameters/index.dart' as admin_subcategory_parameters_index;
import '../routes/admin/subcategory-parameters/[id]/index.dart' as admin_subcategory_parameters_$id_index;
import '../routes/admin/streets/index.dart' as admin_streets_index;
import '../routes/admin/stats/index.dart' as admin_stats_index;
import '../routes/admin/sellers/index.dart' as admin_sellers_index;
import '../routes/admin/sellers/[id].dart' as admin_sellers_$id;
import '../routes/admin/reviews/index.dart' as admin_reviews_index;
import '../routes/admin/reviews/[id].dart' as admin_reviews_$id;
import '../routes/admin/products/index.dart' as admin_products_index;
import '../routes/admin/products/[id].dart' as admin_products_$id;
import '../routes/admin/podcategories/index.dart' as admin_podcategories_index;
import '../routes/admin/podcategories/[id].dart' as admin_podcategories_$id;
import '../routes/admin/pickup-points/index.dart' as admin_pickup_points_index;
import '../routes/admin/pickup-points/[id].dart' as admin_pickup_points_$id;
import '../routes/admin/payments/index.dart' as admin_payments_index;
import '../routes/admin/payments/[id].dart' as admin_payments_$id;
import '../routes/admin/payment-methods/index.dart' as admin_payment_methods_index;
import '../routes/admin/payment-methods/[id].dart' as admin_payment_methods_$id;
import '../routes/admin/parameters/index.dart' as admin_parameters_index;
import '../routes/admin/parameters/[id].dart' as admin_parameters_$id;
import '../routes/admin/orders/index.dart' as admin_orders_index;
import '../routes/admin/orders/[id].dart' as admin_orders_$id;
import '../routes/admin/measurement-units/index.dart' as admin_measurement_units_index;
import '../routes/admin/measurement-units/[id].dart' as admin_measurement_units_$id;
import '../routes/admin/list-types/index.dart' as admin_list_types_index;
import '../routes/admin/list-types/[id].dart' as admin_list_types_$id;
import '../routes/admin/images/index.dart' as admin_images_index;
import '../routes/admin/images/[id].dart' as admin_images_$id;
import '../routes/admin/houses/index.dart' as admin_houses_index;
import '../routes/admin/cities/index.dart' as admin_cities_index;
import '../routes/admin/cities/[id].dart' as admin_cities_$id;
import '../routes/admin/categories/index.dart' as admin_categories_index;
import '../routes/admin/categories/[id].dart' as admin_categories_$id;

import '../routes/_middleware.dart' as middleware;
import '../routes/seller/_middleware.dart' as seller_middleware;
import '../routes/reviews/_middleware.dart' as reviews_middleware;
import '../routes/payments/_middleware.dart' as payments_middleware;
import '../routes/orders/_middleware.dart' as orders_middleware;
import '../routes/me/_middleware.dart' as me_middleware;
import '../routes/favorites/_middleware.dart' as favorites_middleware;
import '../routes/checkout/_middleware.dart' as checkout_middleware;
import '../routes/cart/_middleware.dart' as cart_middleware;
import '../routes/admin/_middleware.dart' as admin_middleware;
import '../routes/admin/reviews/_middleware.dart' as admin_reviews_middleware;

void main() async {
  final address = InternetAddress.tryParse('') ?? InternetAddress.anyIPv6;
  final port = int.tryParse(Platform.environment['PORT'] ?? '8080') ?? 8080;
  hotReload(() => createServer(address, port));
}

Future<HttpServer> createServer(InternetAddress address, int port) {
  final handler = Cascade().add(buildRootHandler()).handler;
  return serve(handler, address, port);
}

Handler buildRootHandler() {
  final pipeline = const Pipeline().addMiddleware(middleware.middleware);
  final router = Router()
    ..mount('/', (context) => buildHandler()(context))
    ..mount('/subcategories/<id>', (context,id,) => buildSubcategories$idHandler(id,)(context))
    ..mount('/seller', (context) => buildSellerHandler()(context))
    ..mount('/seller/products', (context) => buildSellerProductsHandler()(context))
    ..mount('/seller/products/<id>', (context,id,) => buildSellerProducts$idHandler(id,)(context))
    ..mount('/seller/orders', (context) => buildSellerOrdersHandler()(context))
    ..mount('/reviews', (context) => buildReviewsHandler()(context))
    ..mount('/products', (context) => buildProductsHandler()(context))
    ..mount('/products/<id>', (context,id,) => buildProducts$idHandler(id,)(context))
    ..mount('/pickup-points', (context) => buildPickupPointsHandler()(context))
    ..mount('/payments', (context) => buildPaymentsHandler()(context))
    ..mount('/payment-methods', (context) => buildPaymentMethodsHandler()(context))
    ..mount('/orders', (context) => buildOrdersHandler()(context))
    ..mount('/measurement-units', (context) => buildMeasurementUnitsHandler()(context))
    ..mount('/me', (context) => buildMeHandler()(context))
    ..mount('/me/pickup-points', (context) => buildMePickupPointsHandler()(context))
    ..mount('/me/cards', (context) => buildMeCardsHandler()(context))
    ..mount('/list-types', (context) => buildListTypesHandler()(context))
    ..mount('/favorites', (context) => buildFavoritesHandler()(context))
    ..mount('/cities', (context) => buildCitiesHandler()(context))
    ..mount('/checkout', (context) => buildCheckoutHandler()(context))
    ..mount('/categories', (context) => buildCategoriesHandler()(context))
    ..mount('/categories/<id>', (context,id,) => buildCategories$idHandler(id,)(context))
    ..mount('/cart', (context) => buildCartHandler()(context))
    ..mount('/cart/items', (context) => buildCartItemsHandler()(context))
    ..mount('/auth', (context) => buildAuthHandler()(context))
    ..mount('/admin/users', (context) => buildAdminUsersHandler()(context))
    ..mount('/admin/subcategory-parameters', (context) => buildAdminSubcategoryParametersHandler()(context))
    ..mount('/admin/subcategory-parameters/<id>', (context,id,) => buildAdminSubcategoryParameters$idHandler(id,)(context))
    ..mount('/admin/streets', (context) => buildAdminStreetsHandler()(context))
    ..mount('/admin/stats', (context) => buildAdminStatsHandler()(context))
    ..mount('/admin/sellers', (context) => buildAdminSellersHandler()(context))
    ..mount('/admin/reviews', (context) => buildAdminReviewsHandler()(context))
    ..mount('/admin/products', (context) => buildAdminProductsHandler()(context))
    ..mount('/admin/podcategories', (context) => buildAdminPodcategoriesHandler()(context))
    ..mount('/admin/pickup-points', (context) => buildAdminPickupPointsHandler()(context))
    ..mount('/admin/payments', (context) => buildAdminPaymentsHandler()(context))
    ..mount('/admin/payment-methods', (context) => buildAdminPaymentMethodsHandler()(context))
    ..mount('/admin/parameters', (context) => buildAdminParametersHandler()(context))
    ..mount('/admin/orders', (context) => buildAdminOrdersHandler()(context))
    ..mount('/admin/measurement-units', (context) => buildAdminMeasurementUnitsHandler()(context))
    ..mount('/admin/list-types', (context) => buildAdminListTypesHandler()(context))
    ..mount('/admin/images', (context) => buildAdminImagesHandler()(context))
    ..mount('/admin/houses', (context) => buildAdminHousesHandler()(context))
    ..mount('/admin/cities', (context) => buildAdminCitiesHandler()(context))
    ..mount('/admin/categories', (context) => buildAdminCategoriesHandler()(context));
  return pipeline.addHandler(router);
}

Handler buildHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/health', (context) => health.onRequest(context,))..all('/', (context) => index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildSubcategories$idHandler(String id,) {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/filters', (context) => subcategories_$id_filters.onRequest(context,id,))..all('/parameters', (context) => subcategories_$id_parameters.onRequest(context,id,));
  return pipeline.addHandler(router);
}

Handler buildSellerHandler() {
  final pipeline = const Pipeline().addMiddleware(seller_middleware.middleware);
  final router = Router()
    ..all('/profile', (context) => seller_profile.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildSellerProductsHandler() {
  final pipeline = const Pipeline().addMiddleware(seller_middleware.middleware);
  final router = Router()
    ..all('/', (context) => seller_products_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildSellerProducts$idHandler(String id,) {
  final pipeline = const Pipeline().addMiddleware(seller_middleware.middleware);
  final router = Router()
    ..all('/images', (context) => seller_products_$id_images.onRequest(context,id,))..all('/parameters', (context) => seller_products_$id_parameters.onRequest(context,id,))..all('/set_main_image', (context) => seller_products_$id_set_main_image.onRequest(context,id,))..all('/upload_image', (context) => seller_products_$id_upload_image.onRequest(context,id,))..all('/', (context) => seller_products_$id_index.onRequest(context,id,));
  return pipeline.addHandler(router);
}

Handler buildSellerOrdersHandler() {
  final pipeline = const Pipeline().addMiddleware(seller_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => seller_orders_$id.onRequest(context,id,))..all('/', (context) => seller_orders_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildReviewsHandler() {
  final pipeline = const Pipeline().addMiddleware(reviews_middleware.middleware);
  final router = Router()
    ..all('/can-review', (context) => reviews_can_review.onRequest(context,))..all('/', (context) => reviews_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildProductsHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/search_filters', (context) => products_search_filters.onRequest(context,))..all('/', (context) => products_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildProducts$idHandler(String id,) {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/images', (context) => products_$id_images.onRequest(context,id,))..all('/parameters', (context) => products_$id_parameters.onRequest(context,id,))..all('/reviews', (context) => products_$id_reviews.onRequest(context,id,))..all('/', (context) => products_$id_index.onRequest(context,id,));
  return pipeline.addHandler(router);
}

Handler buildPickupPointsHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/', (context) => pickup_points_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildPaymentsHandler() {
  final pipeline = const Pipeline().addMiddleware(payments_middleware.middleware);
  final router = Router()
    ..all('/', (context) => payments_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildPaymentMethodsHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/', (context) => payment_methods_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildOrdersHandler() {
  final pipeline = const Pipeline().addMiddleware(orders_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => orders_$id.onRequest(context,id,))..all('/', (context) => orders_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildMeasurementUnitsHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/<id>', (context,id,) => measurement_units_$id.onRequest(context,id,))..all('/', (context) => measurement_units_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildMeHandler() {
  final pipeline = const Pipeline().addMiddleware(me_middleware.middleware);
  final router = Router()
    ..all('/', (context) => me_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildMePickupPointsHandler() {
  final pipeline = const Pipeline().addMiddleware(me_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => me_pickup_points_$id.onRequest(context,id,))..all('/', (context) => me_pickup_points_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildMeCardsHandler() {
  final pipeline = const Pipeline().addMiddleware(me_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => me_cards_$id.onRequest(context,id,))..all('/', (context) => me_cards_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildListTypesHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/', (context) => list_types_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildFavoritesHandler() {
  final pipeline = const Pipeline().addMiddleware(favorites_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => favorites_$id.onRequest(context,id,))..all('/', (context) => favorites_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildCitiesHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/', (context) => cities_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildCheckoutHandler() {
  final pipeline = const Pipeline().addMiddleware(checkout_middleware.middleware);
  final router = Router()
    ..all('/create', (context) => checkout_create.onRequest(context,))..all('/preview', (context) => checkout_preview.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildCategoriesHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/', (context) => categories_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildCategories$idHandler(String id,) {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/subcategories', (context) => categories_$id_subcategories.onRequest(context,id,))..all('/subcategory_parameters', (context) => categories_$id_subcategory_parameters.onRequest(context,id,));
  return pipeline.addHandler(router);
}

Handler buildCartHandler() {
  final pipeline = const Pipeline().addMiddleware(cart_middleware.middleware);
  final router = Router()
    ..all('/', (context) => cart_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildCartItemsHandler() {
  final pipeline = const Pipeline().addMiddleware(cart_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => cart_items_$id.onRequest(context,id,))..all('/', (context) => cart_items_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAuthHandler() {
  final pipeline = const Pipeline();
  final router = Router()
    ..all('/forgot-password', (context) => auth_forgot_password.onRequest(context,))..all('/login', (context) => auth_login.onRequest(context,))..all('/logout', (context) => auth_logout.onRequest(context,))..all('/refresh', (context) => auth_refresh.onRequest(context,))..all('/register', (context) => auth_register.onRequest(context,))..all('/resend-verification-code', (context) => auth_resend_verification_code.onRequest(context,))..all('/reset-password', (context) => auth_reset_password.onRequest(context,))..all('/verify-email', (context) => auth_verify_email.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminUsersHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_users_$id.onRequest(context,id,))..all('/', (context) => admin_users_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminSubcategoryParametersHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/', (context) => admin_subcategory_parameters_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminSubcategoryParameters$idHandler(String id,) {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/', (context) => admin_subcategory_parameters_$id_index.onRequest(context,id,));
  return pipeline.addHandler(router);
}

Handler buildAdminStreetsHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/', (context) => admin_streets_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminStatsHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/', (context) => admin_stats_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminSellersHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_sellers_$id.onRequest(context,id,))..all('/', (context) => admin_sellers_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminReviewsHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware).addMiddleware(admin_reviews_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_reviews_$id.onRequest(context,id,))..all('/', (context) => admin_reviews_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminProductsHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_products_$id.onRequest(context,id,))..all('/', (context) => admin_products_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminPodcategoriesHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_podcategories_$id.onRequest(context,id,))..all('/', (context) => admin_podcategories_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminPickupPointsHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_pickup_points_$id.onRequest(context,id,))..all('/', (context) => admin_pickup_points_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminPaymentsHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_payments_$id.onRequest(context,id,))..all('/', (context) => admin_payments_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminPaymentMethodsHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_payment_methods_$id.onRequest(context,id,))..all('/', (context) => admin_payment_methods_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminParametersHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_parameters_$id.onRequest(context,id,))..all('/', (context) => admin_parameters_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminOrdersHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_orders_$id.onRequest(context,id,))..all('/', (context) => admin_orders_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminMeasurementUnitsHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_measurement_units_$id.onRequest(context,id,))..all('/', (context) => admin_measurement_units_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminListTypesHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_list_types_$id.onRequest(context,id,))..all('/', (context) => admin_list_types_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminImagesHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_images_$id.onRequest(context,id,))..all('/', (context) => admin_images_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminHousesHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/', (context) => admin_houses_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminCitiesHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_cities_$id.onRequest(context,id,))..all('/', (context) => admin_cities_index.onRequest(context,));
  return pipeline.addHandler(router);
}

Handler buildAdminCategoriesHandler() {
  final pipeline = const Pipeline().addMiddleware(admin_middleware.middleware);
  final router = Router()
    ..all('/<id>', (context,id,) => admin_categories_$id.onRequest(context,id,))..all('/', (context) => admin_categories_index.onRequest(context,));
  return pipeline.addHandler(router);
}

